'use client';

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Users, 
  ChefHat, 
  Calendar, 
  DollarSign, 
  TrendingUp, 
  Star,
  CheckCircle,
  XCircle,
  Eye,
  Search,
  Filter
} from 'lucide-react';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const queryClient = useQueryClient();

  // Fetch dashboard stats
  const { data: stats } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: async () => {
      const [usersRes, chefsRes, bookingsRes] = await Promise.all([
        fetch('/api/users?limit=1'),
        fetch('/api/chefs?limit=1'),
        fetch('/api/bookings?limit=1')
      ]);
      
      const [usersData, chefsData, bookingsData] = await Promise.all([
        usersRes.json(),
        chefsRes.json(),
        bookingsRes.json()
      ]);

      return {
        totalUsers: usersData.pagination?.total || 0,
        totalChefs: chefsData.pagination?.total || 0,
        totalBookings: bookingsData.pagination?.total || 0,
        revenue: 25000 // Mock revenue data
      };
    },
  });

  // Fetch pending chef approvals
  const { data: pendingChefs } = useQuery({
    queryKey: ['pending-chefs'],
    queryFn: async () => {
      const response = await fetch('/api/chefs?isApproved=false&limit=10');
      if (!response.ok) throw new Error('Failed to fetch pending chefs');
      const data = await response.json();
      return data.chefs || [];
    },
  });

  // Fetch recent bookings
  const { data: recentBookings } = useQuery({
    queryKey: ['recent-bookings'],
    queryFn: async () => {
      const response = await fetch('/api/bookings?limit=10');
      if (!response.ok) throw new Error('Failed to fetch recent bookings');
      const data = await response.json();
      return data.bookings || [];
    },
  });

  // Approve chef mutation
  const approveChefMutation = useMutation({
    mutationFn: async (chefId) => {
      const response = await fetch(`/api/chefs/${chefId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isApproved: true }),
      });
      if (!response.ok) throw new Error('Failed to approve chef');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-chefs'] });
      queryClient.invalidateQueries({ queryKey: ['admin-stats'] });
    },
  });

  // Reject chef mutation
  const rejectChefMutation = useMutation({
    mutationFn: async (chefId) => {
      const response = await fetch(`/api/chefs/${chefId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isApproved: false }),
      });
      if (!response.ok) throw new Error('Failed to reject chef');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-chefs'] });
    },
  });

  const handleApproveChef = (chefId) => {
    if (confirm('Are you sure you want to approve this chef?')) {
      approveChefMutation.mutate(chefId);
    }
  };

  const handleRejectChef = (chefId) => {
    if (confirm('Are you sure you want to reject this chef?')) {
      rejectChefMutation.mutate(chefId);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <ChefHat className="h-8 w-8 text-orange-500" />
              <h1 className="ml-2 text-2xl font-bold text-gray-900">ChefBooking Admin</h1>
            </div>
            <nav className="flex space-x-8">
              <a href="/" className="text-gray-700 hover:text-orange-500">Back to Site</a>
              <a href="#" className="text-gray-700 hover:text-orange-500">Settings</a>
              <a href="#" className="text-gray-700 hover:text-orange-500">Logout</a>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tab Navigation */}
        <div className="mb-8">
          <nav className="flex space-x-8">
            {[
              { id: 'overview', label: 'Overview', icon: TrendingUp },
              { id: 'chefs', label: 'Chef Approvals', icon: ChefHat },
              { id: 'bookings', label: 'Bookings', icon: Calendar },
              { id: 'users', label: 'Users', icon: Users },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                    activeTab === tab.id
                      ? 'bg-orange-100 text-orange-700'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <Icon className="h-5 w-5 mr-2" />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Users className="h-8 w-8 text-blue-500" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Users</p>
                    <p className="text-2xl font-semibold text-gray-900">{stats?.totalUsers || 0}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <ChefHat className="h-8 w-8 text-orange-500" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Chefs</p>
                    <p className="text-2xl font-semibold text-gray-900">{stats?.totalChefs || 0}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Calendar className="h-8 w-8 text-green-500" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Bookings</p>
                    <p className="text-2xl font-semibold text-gray-900">{stats?.totalBookings || 0}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <DollarSign className="h-8 w-8 text-purple-500" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Revenue</p>
                    <p className="text-2xl font-semibold text-gray-900">${stats?.revenue?.toLocaleString() || 0}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Pending Chef Approvals */}
              <div className="bg-white rounded-lg shadow">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900">Pending Chef Approvals</h3>
                </div>
                <div className="p-6">
                  {pendingChefs && pendingChefs.length > 0 ? (
                    <div className="space-y-4">
                      {pendingChefs.slice(0, 5).map((chef) => (
                        <div key={chef.id} className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="h-10 w-10 bg-orange-100 rounded-full flex items-center justify-center">
                              <ChefHat className="h-5 w-5 text-orange-500" />
                            </div>
                            <div className="ml-3">
                              <p className="text-sm font-medium text-gray-900">
                                {chef.first_name} {chef.last_name}
                              </p>
                              <p className="text-sm text-gray-500">{chef.email}</p>
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <button
                              onClick={() => handleApproveChef(chef.id)}
                              className="p-1 text-green-600 hover:text-green-800"
                            >
                              <CheckCircle className="h-5 w-5" />
                            </button>
                            <button
                              onClick={() => handleRejectChef(chef.id)}
                              className="p-1 text-red-600 hover:text-red-800"
                            >
                              <XCircle className="h-5 w-5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500">No pending approvals</p>
                  )}
                </div>
              </div>

              {/* Recent Bookings */}
              <div className="bg-white rounded-lg shadow">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900">Recent Bookings</h3>
                </div>
                <div className="p-6">
                  {recentBookings && recentBookings.length > 0 ? (
                    <div className="space-y-4">
                      {recentBookings.slice(0, 5).map((booking) => (
                        <div key={booking.id} className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-gray-900">
                              {booking.user_first_name} {booking.user_last_name}
                            </p>
                            <p className="text-sm text-gray-500">
                              with Chef {booking.chef_first_name} {booking.chef_last_name}
                            </p>
                            <p className="text-xs text-gray-400">
                              {new Date(booking.booking_date).toLocaleDateString()} at {booking.start_time}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium text-gray-900">${booking.total_amount}</p>
                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                              booking.status === 'confirmed' 
                                ? 'bg-green-100 text-green-800'
                                : booking.status === 'pending'
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}>
                              {booking.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500">No recent bookings</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Chef Approvals Tab */}
        {activeTab === 'chefs' && (
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">Chef Approval Queue</h3>
                <div className="flex space-x-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search chefs..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Chef
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Experience
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Location
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Rate
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Applied
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {pendingChefs && pendingChefs.map((chef) => (
                    <tr key={chef.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-10 w-10 bg-orange-100 rounded-full flex items-center justify-center">
                            <ChefHat className="h-5 w-5 text-orange-500" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                              {chef.first_name} {chef.last_name}
                            </div>
                            <div className="text-sm text-gray-500">{chef.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {chef.experience_years} years
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {chef.location || 'Not specified'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${chef.hourly_rate || 0}/hour
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(chef.created_at).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => window.open(`/chef/${chef.id}`, '_blank')}
                            className="text-blue-600 hover:text-blue-900"
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleApproveChef(chef.id)}
                            className="text-green-600 hover:text-green-900"
                          >
                            <CheckCircle className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleRejectChef(chef.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <XCircle className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Other tabs would be implemented similarly */}
        {activeTab === 'bookings' && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Bookings Management</h3>
            <p className="text-gray-500">Bookings management interface would go here...</p>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">User Management</h3>
            <p className="text-gray-500">User management interface would go here...</p>
          </div>
        )}
      </div>
    </div>
  );
}