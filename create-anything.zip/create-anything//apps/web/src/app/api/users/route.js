import sql from "@/app/api/utils/sql";
import { hash } from "argon2";

// Create a new user
export async function POST(request) {
  try {
    const { email, password, firstName, lastName, phone, profileImage } = await request.json();

    if (!email || !password || !firstName || !lastName) {
      return Response.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Check if user already exists
    const existingUser = await sql`
      SELECT id FROM users WHERE email = ${email}
    `;

    if (existingUser.length > 0) {
      return Response.json({ error: "User already exists" }, { status: 409 });
    }

    // Hash password
    const passwordHash = await hash(password);

    // Create user
    const [user] = await sql`
      INSERT INTO users (email, password_hash, first_name, last_name, phone, profile_image)
      VALUES (${email}, ${passwordHash}, ${firstName}, ${lastName}, ${phone || null}, ${profileImage || null})
      RETURNING id, email, first_name, last_name, phone, profile_image, created_at
    `;

    return Response.json({ user }, { status: 201 });
  } catch (error) {
    console.error("Error creating user:", error);
    return Response.json({ error: "Failed to create user" }, { status: 500 });
  }
}

// Get all users (with pagination and search)
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const search = searchParams.get('search') || '';
    const offset = (page - 1) * limit;

    let query = `
      SELECT id, email, first_name, last_name, phone, profile_image, created_at
      FROM users
      WHERE 1=1
    `;
    let params = [];
    let paramIndex = 1;

    if (search) {
      query += ` AND (LOWER(first_name) LIKE LOWER($${paramIndex}) OR LOWER(last_name) LIKE LOWER($${paramIndex + 1}) OR LOWER(email) LIKE LOWER($${paramIndex + 2}))`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
      paramIndex += 3;
    }

    query += ` ORDER BY created_at DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    params.push(limit, offset);

    const users = await sql(query, params);

    // Get total count
    let countQuery = `SELECT COUNT(*) as total FROM users WHERE 1=1`;
    let countParams = [];
    let countParamIndex = 1;

    if (search) {
      countQuery += ` AND (LOWER(first_name) LIKE LOWER($${countParamIndex}) OR LOWER(last_name) LIKE LOWER($${countParamIndex + 1}) OR LOWER(email) LIKE LOWER($${countParamIndex + 2}))`;
      countParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    const [{ total }] = await sql(countQuery, countParams);

    return Response.json({
      users,
      pagination: {
        page,
        limit,
        total: parseInt(total),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error("Error fetching users:", error);
    return Response.json({ error: "Failed to fetch users" }, { status: 500 });
  }
}