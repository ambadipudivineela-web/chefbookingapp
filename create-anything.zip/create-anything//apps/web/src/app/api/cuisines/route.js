import sql from "@/app/api/utils/sql";

// Get all cuisines
export async function GET(request) {
  try {
    const cuisines = await sql`
      SELECT id, name, description
      FROM cuisines
      ORDER BY name ASC
    `;

    return Response.json(cuisines);
  } catch (error) {
    console.error("Error fetching cuisines:", error);
    return Response.json({ error: "Failed to fetch cuisines" }, { status: 500 });
  }
}

// Create a new cuisine
export async function POST(request) {
  try {
    const { name, description } = await request.json();

    if (!name) {
      return Response.json({ error: "Name is required" }, { status: 400 });
    }

    // Check if cuisine already exists
    const existingCuisine = await sql`
      SELECT id FROM cuisines WHERE LOWER(name) = LOWER(${name})
    `;

    if (existingCuisine.length > 0) {
      return Response.json({ error: "Cuisine already exists" }, { status: 409 });
    }

    // Create cuisine
    const [cuisine] = await sql`
      INSERT INTO cuisines (name, description)
      VALUES (${name}, ${description || null})
      RETURNING id, name, description
    `;

    return Response.json({ cuisine }, { status: 201 });
  } catch (error) {
    console.error("Error creating cuisine:", error);
    return Response.json({ error: "Failed to create cuisine" }, { status: 500 });
  }
}