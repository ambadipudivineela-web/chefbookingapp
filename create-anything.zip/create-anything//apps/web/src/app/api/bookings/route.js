import sql from "@/app/api/utils/sql";

// Create a new booking
export async function POST(request) {
  try {
    const { 
      userId, 
      chefId, 
      bookingDate, 
      startTime, 
      endTime, 
      partySize, 
      specialRequests, 
      totalAmount 
    } = await request.json();

    if (!userId || !chefId || !bookingDate || !startTime || !endTime || !partySize || !totalAmount) {
      return Response.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Check if chef is available at the requested time
    const availability = await sql`
      SELECT id FROM chef_availability 
      WHERE chef_id = ${chefId} 
        AND date = ${bookingDate}
        AND start_time <= ${startTime}
        AND end_time >= ${endTime}
        AND is_booked = false
    `;

    if (availability.length === 0) {
      return Response.json({ error: "Chef is not available at the requested time" }, { status: 409 });
    }

    // Check for conflicting bookings
    const conflictingBookings = await sql`
      SELECT id FROM bookings 
      WHERE chef_id = ${chefId} 
        AND booking_date = ${bookingDate}
        AND status NOT IN ('cancelled')
        AND (
          (start_time <= ${startTime} AND end_time > ${startTime}) OR
          (start_time < ${endTime} AND end_time >= ${endTime}) OR
          (start_time >= ${startTime} AND end_time <= ${endTime})
        )
    `;

    if (conflictingBookings.length > 0) {
      return Response.json({ error: "Time slot is already booked" }, { status: 409 });
    }

    // Create booking
    const [booking] = await sql`
      INSERT INTO bookings (
        user_id, chef_id, booking_date, start_time, end_time, 
        party_size, special_requests, total_amount
      )
      VALUES (
        ${userId}, ${chefId}, ${bookingDate}, ${startTime}, ${endTime}, 
        ${partySize}, ${specialRequests || null}, ${totalAmount}
      )
      RETURNING id, user_id, chef_id, booking_date, start_time, end_time, 
                party_size, special_requests, total_amount, status, 
                payment_status, created_at
    `;

    // Mark availability slot as booked
    await sql`
      UPDATE chef_availability 
      SET is_booked = true 
      WHERE chef_id = ${chefId} 
        AND date = ${bookingDate}
        AND start_time <= ${startTime}
        AND end_time >= ${endTime}
    `;

    // Create notification for chef
    await sql`
      INSERT INTO notifications (chef_id, type, title, message)
      VALUES (
        ${chefId}, 
        'booking_request', 
        'New Booking Request', 
        'You have received a new booking request for ${bookingDate}'
      )
    `;

    return Response.json({ booking }, { status: 201 });
  } catch (error) {
    console.error("Error creating booking:", error);
    return Response.json({ error: "Failed to create booking" }, { status: 500 });
  }
}

// Get all bookings with filters
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const userId = searchParams.get('userId');
    const chefId = searchParams.get('chefId');
    const status = searchParams.get('status');
    const paymentStatus = searchParams.get('paymentStatus');
    const fromDate = searchParams.get('fromDate');
    const toDate = searchParams.get('toDate');
    const offset = (page - 1) * limit;

    let query = `
      SELECT b.id, b.user_id, b.chef_id, b.booking_date, b.start_time, b.end_time,
             b.party_size, b.special_requests, b.total_amount, b.status, 
             b.payment_status, b.payment_id, b.created_at, b.updated_at,
             u.first_name as user_first_name, u.last_name as user_last_name, u.email as user_email,
             c.first_name as chef_first_name, c.last_name as chef_last_name, c.email as chef_email
      FROM bookings b
      LEFT JOIN users u ON b.user_id = u.id
      LEFT JOIN chefs c ON b.chef_id = c.id
      WHERE 1=1
    `;
    let params = [];
    let paramIndex = 1;

    if (userId) {
      query += ` AND b.user_id = $${paramIndex}`;
      params.push(userId);
      paramIndex++;
    }

    if (chefId) {
      query += ` AND b.chef_id = $${paramIndex}`;
      params.push(chefId);
      paramIndex++;
    }

    if (status) {
      query += ` AND b.status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    if (paymentStatus) {
      query += ` AND b.payment_status = $${paramIndex}`;
      params.push(paymentStatus);
      paramIndex++;
    }

    if (fromDate) {
      query += ` AND b.booking_date >= $${paramIndex}`;
      params.push(fromDate);
      paramIndex++;
    }

    if (toDate) {
      query += ` AND b.booking_date <= $${paramIndex}`;
      params.push(toDate);
      paramIndex++;
    }

    query += ` ORDER BY b.booking_date DESC, b.start_time DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    params.push(limit, offset);

    const bookings = await sql(query, params);

    // Get total count
    let countQuery = `SELECT COUNT(*) as total FROM bookings b WHERE 1=1`;
    let countParams = [];
    let countParamIndex = 1;

    if (userId) {
      countQuery += ` AND b.user_id = $${countParamIndex}`;
      countParams.push(userId);
      countParamIndex++;
    }

    if (chefId) {
      countQuery += ` AND b.chef_id = $${countParamIndex}`;
      countParams.push(chefId);
      countParamIndex++;
    }

    if (status) {
      countQuery += ` AND b.status = $${countParamIndex}`;
      countParams.push(status);
      countParamIndex++;
    }

    if (paymentStatus) {
      countQuery += ` AND b.payment_status = $${countParamIndex}`;
      countParams.push(paymentStatus);
      countParamIndex++;
    }

    if (fromDate) {
      countQuery += ` AND b.booking_date >= $${countParamIndex}`;
      countParams.push(fromDate);
      countParamIndex++;
    }

    if (toDate) {
      countQuery += ` AND b.booking_date <= $${countParamIndex}`;
      countParams.push(toDate);
      countParamIndex++;
    }

    const [{ total }] = await sql(countQuery, countParams);

    return Response.json({
      bookings,
      pagination: {
        page,
        limit,
        total: parseInt(total),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error("Error fetching bookings:", error);
    return Response.json({ error: "Failed to fetch bookings" }, { status: 500 });
  }
}