import sql from "@/app/api/utils/sql";

// Create chef availability
export async function POST(request) {
  try {
    const { chefId, date, startTime, endTime } = await request.json();

    if (!chefId || !date || !startTime || !endTime) {
      return Response.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Validate that start time is before end time
    if (startTime >= endTime) {
      return Response.json({ error: "Start time must be before end time" }, { status: 400 });
    }

    // Check for overlapping availability slots
    const overlapping = await sql`
      SELECT id FROM chef_availability 
      WHERE chef_id = ${chefId} 
        AND date = ${date}
        AND (
          (start_time <= ${startTime} AND end_time > ${startTime}) OR
          (start_time < ${endTime} AND end_time >= ${endTime}) OR
          (start_time >= ${startTime} AND end_time <= ${endTime})
        )
    `;

    if (overlapping.length > 0) {
      return Response.json({ error: "Overlapping availability slot exists" }, { status: 409 });
    }

    // Create availability slot
    const [availability] = await sql`
      INSERT INTO chef_availability (chef_id, date, start_time, end_time)
      VALUES (${chefId}, ${date}, ${startTime}, ${endTime})
      RETURNING id, chef_id, date, start_time, end_time, is_booked, created_at
    `;

    return Response.json({ availability }, { status: 201 });
  } catch (error) {
    console.error("Error creating chef availability:", error);
    return Response.json({ error: "Failed to create chef availability" }, { status: 500 });
  }
}

// Get chef availability with filters
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');
    const chefId = searchParams.get('chefId');
    const date = searchParams.get('date');
    const fromDate = searchParams.get('fromDate');
    const toDate = searchParams.get('toDate');
    const isBooked = searchParams.get('isBooked');
    const offset = (page - 1) * limit;

    let query = `
      SELECT ca.id, ca.chef_id, ca.date, ca.start_time, ca.end_time, ca.is_booked, ca.created_at,
             c.first_name as chef_first_name, c.last_name as chef_last_name
      FROM chef_availability ca
      LEFT JOIN chefs c ON ca.chef_id = c.id
      WHERE 1=1
    `;
    let params = [];
    let paramIndex = 1;

    if (chefId) {
      query += ` AND ca.chef_id = $${paramIndex}`;
      params.push(chefId);
      paramIndex++;
    }

    if (date) {
      query += ` AND ca.date = $${paramIndex}`;
      params.push(date);
      paramIndex++;
    }

    if (fromDate) {
      query += ` AND ca.date >= $${paramIndex}`;
      params.push(fromDate);
      paramIndex++;
    }

    if (toDate) {
      query += ` AND ca.date <= $${paramIndex}`;
      params.push(toDate);
      paramIndex++;
    }

    if (isBooked !== null && isBooked !== undefined) {
      query += ` AND ca.is_booked = $${paramIndex}`;
      params.push(isBooked === 'true');
      paramIndex++;
    }

    // Only show future availability by default
    if (!date && !fromDate) {
      query += ` AND ca.date >= CURRENT_DATE`;
    }

    query += ` ORDER BY ca.date ASC, ca.start_time ASC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    params.push(limit, offset);

    const availability = await sql(query, params);

    // Get total count
    let countQuery = `SELECT COUNT(*) as total FROM chef_availability ca WHERE 1=1`;
    let countParams = [];
    let countParamIndex = 1;

    if (chefId) {
      countQuery += ` AND ca.chef_id = $${countParamIndex}`;
      countParams.push(chefId);
      countParamIndex++;
    }

    if (date) {
      countQuery += ` AND ca.date = $${countParamIndex}`;
      countParams.push(date);
      countParamIndex++;
    }

    if (fromDate) {
      countQuery += ` AND ca.date >= $${countParamIndex}`;
      countParams.push(fromDate);
      countParamIndex++;
    }

    if (toDate) {
      countQuery += ` AND ca.date <= $${countParamIndex}`;
      countParams.push(toDate);
      countParamIndex++;
    }

    if (isBooked !== null && isBooked !== undefined) {
      countQuery += ` AND ca.is_booked = $${countParamIndex}`;
      countParams.push(isBooked === 'true');
      countParamIndex++;
    }

    // Only show future availability by default
    if (!date && !fromDate) {
      countQuery += ` AND ca.date >= CURRENT_DATE`;
    }

    const [{ total }] = await sql(countQuery, countParams);

    return Response.json({
      availability,
      pagination: {
        page,
        limit,
        total: parseInt(total),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error("Error fetching chef availability:", error);
    return Response.json({ error: "Failed to fetch chef availability" }, { status: 500 });
  }
}