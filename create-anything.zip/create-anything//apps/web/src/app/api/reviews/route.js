import sql from "@/app/api/utils/sql";

// Create a new review
export async function POST(request) {
  try {
    const { bookingId, userId, chefId, rating, comment } = await request.json();

    if (!bookingId || !userId || !chefId || !rating) {
      return Response.json({ error: "Missing required fields" }, { status: 400 });
    }

    if (rating < 1 || rating > 5) {
      return Response.json({ error: "Rating must be between 1 and 5" }, { status: 400 });
    }

    // Check if booking exists and is completed
    const [booking] = await sql`
      SELECT id, status FROM bookings 
      WHERE id = ${bookingId} AND user_id = ${userId} AND chef_id = ${chefId}
    `;

    if (!booking) {
      return Response.json({ error: "Booking not found" }, { status: 404 });
    }

    if (booking.status !== 'completed') {
      return Response.json({ error: "Can only review completed bookings" }, { status: 400 });
    }

    // Check if review already exists for this booking
    const existingReview = await sql`
      SELECT id FROM reviews WHERE booking_id = ${bookingId}
    `;

    if (existingReview.length > 0) {
      return Response.json({ error: "Review already exists for this booking" }, { status: 409 });
    }

    // Create review and update chef rating in transaction
    const result = await sql.transaction(async (txn) => {
      // Create the review
      const [review] = await txn`
        INSERT INTO reviews (booking_id, user_id, chef_id, rating, comment)
        VALUES (${bookingId}, ${userId}, ${chefId}, ${rating}, ${comment || null})
        RETURNING id, booking_id, user_id, chef_id, rating, comment, created_at
      `;

      // Update chef's average rating and review count
      const [ratingStats] = await txn`
        SELECT AVG(rating)::DECIMAL(3,2) as avg_rating, COUNT(*) as total_reviews
        FROM reviews 
        WHERE chef_id = ${chefId}
      `;

      await txn`
        UPDATE chefs 
        SET rating = ${ratingStats.avg_rating}, total_reviews = ${ratingStats.total_reviews}
        WHERE id = ${chefId}
      `;

      return review;
    });

    return Response.json({ review: result }, { status: 201 });
  } catch (error) {
    console.error("Error creating review:", error);
    return Response.json({ error: "Failed to create review" }, { status: 500 });
  }
}

// Get reviews with filters
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const chefId = searchParams.get('chefId');
    const userId = searchParams.get('userId');
    const bookingId = searchParams.get('bookingId');
    const minRating = parseInt(searchParams.get('minRating') || '0');
    const offset = (page - 1) * limit;

    let query = `
      SELECT r.id, r.booking_id, r.user_id, r.chef_id, r.rating, r.comment, r.created_at,
             u.first_name as user_first_name, u.last_name as user_last_name,
             c.first_name as chef_first_name, c.last_name as chef_last_name
      FROM reviews r
      LEFT JOIN users u ON r.user_id = u.id
      LEFT JOIN chefs c ON r.chef_id = c.id
      WHERE 1=1
    `;
    let params = [];
    let paramIndex = 1;

    if (chefId) {
      query += ` AND r.chef_id = $${paramIndex}`;
      params.push(chefId);
      paramIndex++;
    }

    if (userId) {
      query += ` AND r.user_id = $${paramIndex}`;
      params.push(userId);
      paramIndex++;
    }

    if (bookingId) {
      query += ` AND r.booking_id = $${paramIndex}`;
      params.push(bookingId);
      paramIndex++;
    }

    if (minRating > 0) {
      query += ` AND r.rating >= $${paramIndex}`;
      params.push(minRating);
      paramIndex++;
    }

    query += ` ORDER BY r.created_at DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    params.push(limit, offset);

    const reviews = await sql(query, params);

    // Get total count
    let countQuery = `SELECT COUNT(*) as total FROM reviews r WHERE 1=1`;
    let countParams = [];
    let countParamIndex = 1;

    if (chefId) {
      countQuery += ` AND r.chef_id = $${countParamIndex}`;
      countParams.push(chefId);
      countParamIndex++;
    }

    if (userId) {
      countQuery += ` AND r.user_id = $${countParamIndex}`;
      countParams.push(userId);
      countParamIndex++;
    }

    if (bookingId) {
      countQuery += ` AND r.booking_id = $${countParamIndex}`;
      countParams.push(bookingId);
      countParamIndex++;
    }

    if (minRating > 0) {
      countQuery += ` AND r.rating >= $${countParamIndex}`;
      countParams.push(minRating);
      countParamIndex++;
    }

    const [{ total }] = await sql(countQuery, countParams);

    return Response.json({
      reviews,
      pagination: {
        page,
        limit,
        total: parseInt(total),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error("Error fetching reviews:", error);
    return Response.json({ error: "Failed to fetch reviews" }, { status: 500 });
  }
}