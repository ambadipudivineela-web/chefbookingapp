import sql from "@/app/api/utils/sql";
import { hash } from "argon2";

// Create a new chef
export async function POST(request) {
  try {
    const { 
      email, 
      password, 
      firstName, 
      lastName, 
      phone, 
      profileImage, 
      bio, 
      experienceYears, 
      location, 
      latitude, 
      longitude, 
      hourlyRate,
      cuisines 
    } = await request.json();

    if (!email || !password || !firstName || !lastName) {
      return Response.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Check if chef already exists
    const existingChef = await sql`
      SELECT id FROM chefs WHERE email = ${email}
    `;

    if (existingChef.length > 0) {
      return Response.json({ error: "Chef already exists" }, { status: 409 });
    }

    // Hash password
    const passwordHash = await hash(password);

    // Create chef
    const [chef] = await sql`
      INSERT INTO chefs (
        email, password_hash, first_name, last_name, phone, profile_image, 
        bio, experience_years, location, latitude, longitude, hourly_rate
      )
      VALUES (
        ${email}, ${passwordHash}, ${firstName}, ${lastName}, ${phone || null}, 
        ${profileImage || null}, ${bio || null}, ${experienceYears || 0}, 
        ${location || null}, ${latitude || null}, ${longitude || null}, ${hourlyRate || null}
      )
      RETURNING id, email, first_name, last_name, phone, profile_image, bio, 
                experience_years, location, latitude, longitude, hourly_rate, 
                is_approved, is_available, rating, total_reviews, created_at
    `;

    // Add chef cuisines if provided
    if (cuisines && cuisines.length > 0) {
      for (const cuisineId of cuisines) {
        await sql`
          INSERT INTO chef_cuisines (chef_id, cuisine_id)
          VALUES (${chef.id}, ${cuisineId})
        `;
      }
    }

    return Response.json({ chef }, { status: 201 });
  } catch (error) {
    console.error("Error creating chef:", error);
    return Response.json({ error: "Failed to create chef" }, { status: 500 });
  }
}

// Get all chefs with filters
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const search = searchParams.get('search') || '';
    const cuisine = searchParams.get('cuisine') || '';
    const location = searchParams.get('location') || '';
    const minRating = parseFloat(searchParams.get('minRating') || '0');
    const maxRate = parseFloat(searchParams.get('maxRate') || '999999');
    const isApproved = searchParams.get('isApproved');
    const isAvailable = searchParams.get('isAvailable');
    const offset = (page - 1) * limit;

    let query = `
      SELECT DISTINCT c.id, c.email, c.first_name, c.last_name, c.phone, c.profile_image, 
             c.bio, c.experience_years, c.location, c.latitude, c.longitude, 
             c.hourly_rate, c.is_approved, c.is_available, c.rating, c.total_reviews, 
             c.created_at,
             ARRAY_AGG(DISTINCT cu.name) as cuisines
      FROM chefs c
      LEFT JOIN chef_cuisines cc ON c.id = cc.chef_id
      LEFT JOIN cuisines cu ON cc.cuisine_id = cu.id
      WHERE 1=1
    `;
    let params = [];
    let paramIndex = 1;

    if (search) {
      query += ` AND (LOWER(c.first_name) LIKE LOWER($${paramIndex}) OR LOWER(c.last_name) LIKE LOWER($${paramIndex + 1}) OR LOWER(c.location) LIKE LOWER($${paramIndex + 2}))`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
      paramIndex += 3;
    }

    if (cuisine) {
      query += ` AND cu.name ILIKE $${paramIndex}`;
      params.push(`%${cuisine}%`);
      paramIndex++;
    }

    if (location) {
      query += ` AND LOWER(c.location) LIKE LOWER($${paramIndex})`;
      params.push(`%${location}%`);
      paramIndex++;
    }

    if (minRating > 0) {
      query += ` AND c.rating >= $${paramIndex}`;
      params.push(minRating);
      paramIndex++;
    }

    if (maxRate < 999999) {
      query += ` AND c.hourly_rate <= $${paramIndex}`;
      params.push(maxRate);
      paramIndex++;
    }

    if (isApproved !== null && isApproved !== undefined) {
      query += ` AND c.is_approved = $${paramIndex}`;
      params.push(isApproved === 'true');
      paramIndex++;
    }

    if (isAvailable !== null && isAvailable !== undefined) {
      query += ` AND c.is_available = $${paramIndex}`;
      params.push(isAvailable === 'true');
      paramIndex++;
    }

    query += ` GROUP BY c.id ORDER BY c.rating DESC, c.created_at DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    params.push(limit, offset);

    const chefs = await sql(query, params);

    // Get total count
    let countQuery = `
      SELECT COUNT(DISTINCT c.id) as total 
      FROM chefs c
      LEFT JOIN chef_cuisines cc ON c.id = cc.chef_id
      LEFT JOIN cuisines cu ON cc.cuisine_id = cu.id
      WHERE 1=1
    `;
    let countParams = [];
    let countParamIndex = 1;

    if (search) {
      countQuery += ` AND (LOWER(c.first_name) LIKE LOWER($${countParamIndex}) OR LOWER(c.last_name) LIKE LOWER($${countParamIndex + 1}) OR LOWER(c.location) LIKE LOWER($${countParamIndex + 2}))`;
      countParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
      countParamIndex += 3;
    }

    if (cuisine) {
      countQuery += ` AND cu.name ILIKE $${countParamIndex}`;
      countParams.push(`%${cuisine}%`);
      countParamIndex++;
    }

    if (location) {
      countQuery += ` AND LOWER(c.location) LIKE LOWER($${countParamIndex})`;
      countParams.push(`%${location}%`);
      countParamIndex++;
    }

    if (minRating > 0) {
      countQuery += ` AND c.rating >= $${countParamIndex}`;
      countParams.push(minRating);
      countParamIndex++;
    }

    if (maxRate < 999999) {
      countQuery += ` AND c.hourly_rate <= $${countParamIndex}`;
      countParams.push(maxRate);
      countParamIndex++;
    }

    if (isApproved !== null && isApproved !== undefined) {
      countQuery += ` AND c.is_approved = $${countParamIndex}`;
      countParams.push(isApproved === 'true');
      countParamIndex++;
    }

    if (isAvailable !== null && isAvailable !== undefined) {
      countQuery += ` AND c.is_available = $${countParamIndex}`;
      countParams.push(isAvailable === 'true');
      countParamIndex++;
    }

    const [{ total }] = await sql(countQuery, countParams);

    return Response.json({
      chefs,
      pagination: {
        page,
        limit,
        total: parseInt(total),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error("Error fetching chefs:", error);
    return Response.json({ error: "Failed to fetch chefs" }, { status: 500 });
  }
}