import sql from "@/app/api/utils/sql";
import { hash } from "argon2";

// Get a specific user
export async function GET(request, { params }) {
  try {
    const { id } = params;

    const [user] = await sql`
      SELECT id, email, first_name, last_name, phone, profile_image, created_at, updated_at
      FROM users
      WHERE id = ${id}
    `;

    if (!user) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    return Response.json({ user });
  } catch (error) {
    console.error("Error fetching user:", error);
    return Response.json({ error: "Failed to fetch user" }, { status: 500 });
  }
}

// Update a user
export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const updates = await request.json();

    // Remove fields that shouldn't be updated directly
    const { password, ...allowedUpdates } = updates;
    
    // Handle password update separately if provided
    if (password) {
      allowedUpdates.password_hash = await hash(password);
    }

    if (Object.keys(allowedUpdates).length === 0) {
      return Response.json({ error: "No valid fields to update" }, { status: 400 });
    }

    // Build dynamic update query
    const setClause = [];
    const values = [];
    let paramIndex = 1;

    for (const [key, value] of Object.entries(allowedUpdates)) {
      // Convert camelCase to snake_case for database fields
      const dbField = key.replace(/([A-Z])/g, '_$1').toLowerCase();
      setClause.push(`${dbField} = $${paramIndex}`);
      values.push(value);
      paramIndex++;
    }

    setClause.push(`updated_at = CURRENT_TIMESTAMP`);
    values.push(id);

    const query = `
      UPDATE users 
      SET ${setClause.join(', ')}
      WHERE id = $${paramIndex}
      RETURNING id, email, first_name, last_name, phone, profile_image, updated_at
    `;

    const [user] = await sql(query, values);

    if (!user) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    return Response.json({ user });
  } catch (error) {
    console.error("Error updating user:", error);
    return Response.json({ error: "Failed to update user" }, { status: 500 });
  }
}

// Delete a user
export async function DELETE(request, { params }) {
  try {
    const { id } = params;

    const [deletedUser] = await sql`
      DELETE FROM users 
      WHERE id = ${id}
      RETURNING id, email, first_name, last_name
    `;

    if (!deletedUser) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    return Response.json({ message: "User deleted successfully", user: deletedUser });
  } catch (error) {
    console.error("Error deleting user:", error);
    return Response.json({ error: "Failed to delete user" }, { status: 500 });
  }
}