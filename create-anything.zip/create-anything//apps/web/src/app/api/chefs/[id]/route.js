import sql from "@/app/api/utils/sql";
import { hash } from "argon2";

// Get a specific chef
export async function GET(request, { params }) {
  try {
    const { id } = params;

    const [chef] = await sql`
      SELECT c.id, c.email, c.first_name, c.last_name, c.phone, c.profile_image, 
             c.bio, c.experience_years, c.location, c.latitude, c.longitude, 
             c.hourly_rate, c.is_approved, c.is_available, c.rating, c.total_reviews, 
             c.created_at, c.updated_at,
             ARRAY_AGG(DISTINCT cu.name) as cuisines
      FROM chefs c
      LEFT JOIN chef_cuisines cc ON c.id = cc.chef_id
      LEFT JOIN cuisines cu ON cc.cuisine_id = cu.id
      WHERE c.id = ${id}
      GROUP BY c.id
    `;

    if (!chef) {
      return Response.json({ error: "Chef not found" }, { status: 404 });
    }

    return Response.json({ chef });
  } catch (error) {
    console.error("Error fetching chef:", error);
    return Response.json({ error: "Failed to fetch chef" }, { status: 500 });
  }
}

// Update a chef
export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const updates = await request.json();

    // Remove fields that shouldn't be updated directly
    const { password, cuisines, ...allowedUpdates } = updates;
    
    // Handle password update separately if provided
    if (password) {
      allowedUpdates.password_hash = await hash(password);
    }

    if (Object.keys(allowedUpdates).length === 0 && !cuisines) {
      return Response.json({ error: "No valid fields to update" }, { status: 400 });
    }

    // Start transaction for chef update and cuisine updates
    const result = await sql.transaction(async (txn) => {
      let updatedChef = null;

      // Update chef basic info if there are fields to update
      if (Object.keys(allowedUpdates).length > 0) {
        // Build dynamic update query
        const setClause = [];
        const values = [];
        let paramIndex = 1;

        for (const [key, value] of Object.entries(allowedUpdates)) {
          // Convert camelCase to snake_case for database fields
          const dbField = key.replace(/([A-Z])/g, '_$1').toLowerCase();
          setClause.push(`${dbField} = $${paramIndex}`);
          values.push(value);
          paramIndex++;
        }

        setClause.push(`updated_at = CURRENT_TIMESTAMP`);
        values.push(id);

        const query = `
          UPDATE chefs 
          SET ${setClause.join(', ')}
          WHERE id = $${paramIndex}
          RETURNING id, email, first_name, last_name, phone, profile_image, bio, 
                    experience_years, location, latitude, longitude, hourly_rate, 
                    is_approved, is_available, rating, total_reviews, updated_at
        `;

        [updatedChef] = await txn(query, values);
      } else {
        // Just get the current chef data
        [updatedChef] = await txn`
          SELECT id, email, first_name, last_name, phone, profile_image, bio, 
                 experience_years, location, latitude, longitude, hourly_rate, 
                 is_approved, is_available, rating, total_reviews, updated_at
          FROM chefs WHERE id = ${id}
        `;
      }

      // Update cuisines if provided
      if (cuisines && Array.isArray(cuisines)) {
        // Remove existing cuisine associations
        await txn`DELETE FROM chef_cuisines WHERE chef_id = ${id}`;
        
        // Add new cuisine associations
        for (const cuisineId of cuisines) {
          await txn`
            INSERT INTO chef_cuisines (chef_id, cuisine_id)
            VALUES (${id}, ${cuisineId})
          `;
        }
      }

      return updatedChef;
    });

    if (!result) {
      return Response.json({ error: "Chef not found" }, { status: 404 });
    }

    return Response.json({ chef: result });
  } catch (error) {
    console.error("Error updating chef:", error);
    return Response.json({ error: "Failed to update chef" }, { status: 500 });
  }
}

// Delete a chef
export async function DELETE(request, { params }) {
  try {
    const { id } = params;

    const [deletedChef] = await sql`
      DELETE FROM chefs 
      WHERE id = ${id}
      RETURNING id, email, first_name, last_name
    `;

    if (!deletedChef) {
      return Response.json({ error: "Chef not found" }, { status: 404 });
    }

    return Response.json({ message: "Chef deleted successfully", chef: deletedChef });
  } catch (error) {
    console.error("Error deleting chef:", error);
    return Response.json({ error: "Failed to delete chef" }, { status: 500 });
  }
}