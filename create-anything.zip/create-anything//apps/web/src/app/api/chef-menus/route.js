import sql from "@/app/api/utils/sql";

// Create a new chef menu
export async function POST(request) {
  try {
    const { chefId, name, description, price, imageUrl, cuisineType } = await request.json();

    if (!chefId || !name || !price) {
      return Response.json({ error: "Missing required fields" }, { status: 400 });
    }

    if (price <= 0) {
      return Response.json({ error: "Price must be greater than 0" }, { status: 400 });
    }

    // Create menu item
    const [menu] = await sql`
      INSERT INTO chef_menus (chef_id, name, description, price, image_url, cuisine_type)
      VALUES (${chefId}, ${name}, ${description || null}, ${price}, ${imageUrl || null}, ${cuisineType || null})
      RETURNING id, chef_id, name, description, price, image_url, cuisine_type, is_available, created_at
    `;

    return Response.json({ menu }, { status: 201 });
  } catch (error) {
    console.error("Error creating chef menu:", error);
    return Response.json({ error: "Failed to create chef menu" }, { status: 500 });
  }
}

// Get chef menus with filters
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const chefId = searchParams.get('chefId');
    const cuisineType = searchParams.get('cuisineType');
    const isAvailable = searchParams.get('isAvailable');
    const minPrice = parseFloat(searchParams.get('minPrice') || '0');
    const maxPrice = parseFloat(searchParams.get('maxPrice') || '999999');
    const offset = (page - 1) * limit;

    let query = `
      SELECT cm.id, cm.chef_id, cm.name, cm.description, cm.price, cm.image_url, 
             cm.cuisine_type, cm.is_available, cm.created_at,
             c.first_name as chef_first_name, c.last_name as chef_last_name
      FROM chef_menus cm
      LEFT JOIN chefs c ON cm.chef_id = c.id
      WHERE 1=1
    `;
    let params = [];
    let paramIndex = 1;

    if (chefId) {
      query += ` AND cm.chef_id = $${paramIndex}`;
      params.push(chefId);
      paramIndex++;
    }

    if (cuisineType) {
      query += ` AND LOWER(cm.cuisine_type) LIKE LOWER($${paramIndex})`;
      params.push(`%${cuisineType}%`);
      paramIndex++;
    }

    if (isAvailable !== null && isAvailable !== undefined) {
      query += ` AND cm.is_available = $${paramIndex}`;
      params.push(isAvailable === 'true');
      paramIndex++;
    }

    if (minPrice > 0) {
      query += ` AND cm.price >= $${paramIndex}`;
      params.push(minPrice);
      paramIndex++;
    }

    if (maxPrice < 999999) {
      query += ` AND cm.price <= $${paramIndex}`;
      params.push(maxPrice);
      paramIndex++;
    }

    query += ` ORDER BY cm.created_at DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    params.push(limit, offset);

    const menus = await sql(query, params);

    // Get total count
    let countQuery = `SELECT COUNT(*) as total FROM chef_menus cm WHERE 1=1`;
    let countParams = [];
    let countParamIndex = 1;

    if (chefId) {
      countQuery += ` AND cm.chef_id = $${countParamIndex}`;
      countParams.push(chefId);
      countParamIndex++;
    }

    if (cuisineType) {
      countQuery += ` AND LOWER(cm.cuisine_type) LIKE LOWER($${countParamIndex})`;
      countParams.push(`%${cuisineType}%`);
      countParamIndex++;
    }

    if (isAvailable !== null && isAvailable !== undefined) {
      countQuery += ` AND cm.is_available = $${countParamIndex}`;
      countParams.push(isAvailable === 'true');
      countParamIndex++;
    }

    if (minPrice > 0) {
      countQuery += ` AND cm.price >= $${countParamIndex}`;
      countParams.push(minPrice);
      countParamIndex++;
    }

    if (maxPrice < 999999) {
      countQuery += ` AND cm.price <= $${countParamIndex}`;
      countParams.push(maxPrice);
      countParamIndex++;
    }

    const [{ total }] = await sql(countQuery, countParams);

    return Response.json({
      menus,
      pagination: {
        page,
        limit,
        total: parseInt(total),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error("Error fetching chef menus:", error);
    return Response.json({ error: "Failed to fetch chef menus" }, { status: 500 });
  }
}