"use client";

import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import useUser from "@/utils/useUser";
import {
  Search,
  MapPin,
  Star,
  Clock,
  Users,
  ChefHat,
  Filter,
} from "lucide-react";

export default function HomePage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCuisine, setSelectedCuisine] = useState("");
  const [location, setLocation] = useState("");
  const [minRating, setMinRating] = useState(0);
  const [showFilters, setShowFilters] = useState(false);

  // Get current user
  const { data: user, loading: userLoading } = useUser();

  // Fetch cuisines for filter dropdown
  const { data: cuisines = [] } = useQuery({
    queryKey: ["cuisines"],
    queryFn: async () => {
      const response = await fetch("/api/cuisines");
      if (!response.ok) throw new Error("Failed to fetch cuisines");
      return response.json();
    },
  });

  // Fetch chefs with filters
  const { data: chefsData, isLoading } = useQuery({
    queryKey: ["chefs", searchTerm, selectedCuisine, location, minRating],
    queryFn: async () => {
      const params = new URLSearchParams({
        isApproved: "true",
        isAvailable: "true",
        limit: "12",
      });

      if (searchTerm) params.append("search", searchTerm);
      if (selectedCuisine) params.append("cuisine", selectedCuisine);
      if (location) params.append("location", location);
      if (minRating > 0) params.append("minRating", minRating.toString());

      const response = await fetch(`/api/chefs?${params}`);
      if (!response.ok) throw new Error("Failed to fetch chefs");
      return response.json();
    },
  });

  const chefs = chefsData?.chefs || [];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <ChefHat className="h-8 w-8 text-orange-500" />
              <h1 className="ml-2 text-2xl font-bold text-gray-900">
                ChefBooking
              </h1>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="/" className="text-gray-700 hover:text-orange-500">
                Find Chefs
              </a>
              <a
                href="/become-chef"
                className="text-gray-700 hover:text-orange-500"
              >
                Become a Chef
              </a>
              <a href="/admin" className="text-gray-700 hover:text-orange-500">
                How it Works
              </a>
              {!userLoading &&
                (user ? (
                  <div className="flex items-center space-x-4">
                    <span className="text-gray-700">
                      Hi, {user.name || user.email}
                    </span>
                    <a
                      href="/account/logout"
                      className="text-gray-700 hover:text-orange-500"
                    >
                      Sign Out
                    </a>
                  </div>
                ) : (
                  <a
                    href="/account/signin"
                    className="text-gray-700 hover:text-orange-500"
                  >
                    Sign In
                  </a>
                ))}
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-orange-500 to-red-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Book Professional Chefs
          </h2>
          <p className="text-xl md:text-2xl mb-8 opacity-90">
            Experience restaurant-quality meals in the comfort of your home
          </p>

          {/* Search Bar */}
          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search chefs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-gray-900"
                />
              </div>

              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-gray-900"
                />
              </div>

              <select
                value={selectedCuisine}
                onChange={(e) => setSelectedCuisine(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-gray-900"
              >
                <option value="">All Cuisines</option>
                {cuisines.map((cuisine) => (
                  <option key={cuisine.id} value={cuisine.name}>
                    {cuisine.name}
                  </option>
                ))}
              </select>

              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center justify-center px-6 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
              >
                <Filter className="h-5 w-5 mr-2" />
                Filters
              </button>
            </div>

            {/* Advanced Filters */}
            {showFilters && (
              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Minimum Rating
                    </label>
                    <select
                      value={minRating}
                      onChange={(e) => setMinRating(Number(e.target.value))}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-gray-900"
                    >
                      <option value={0}>Any Rating</option>
                      <option value={3}>3+ Stars</option>
                      <option value={4}>4+ Stars</option>
                      <option value={4.5}>4.5+ Stars</option>
                    </select>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Featured Chefs */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Featured Chefs
            </h3>
            <p className="text-lg text-gray-600">
              Discover talented chefs in your area
            </p>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div
                  key={i}
                  className="bg-white rounded-lg shadow-md overflow-hidden animate-pulse"
                >
                  <div className="h-48 bg-gray-300"></div>
                  <div className="p-6">
                    <div className="h-4 bg-gray-300 rounded mb-2"></div>
                    <div className="h-4 bg-gray-300 rounded w-2/3 mb-4"></div>
                    <div className="h-3 bg-gray-300 rounded w-1/2"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {chefs.map((chef) => (
                <div
                  key={chef.id}
                  className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <div className="h-48 bg-gradient-to-br from-orange-400 to-red-500 relative">
                    {chef.profile_image ? (
                      <img
                        src={chef.profile_image}
                        alt={`${chef.first_name} ${chef.last_name}`}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <ChefHat className="h-16 w-16 text-white opacity-50" />
                      </div>
                    )}
                    <div className="absolute top-4 right-4 bg-white rounded-full px-2 py-1 flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="ml-1 text-sm font-medium">
                        {chef.rating || "0.0"}
                      </span>
                    </div>
                  </div>

                  <div className="p-6">
                    <h4 className="text-xl font-semibold text-gray-900 mb-2">
                      {chef.first_name} {chef.last_name}
                    </h4>

                    <div className="flex items-center text-gray-600 mb-2">
                      <MapPin className="h-4 w-4 mr-1" />
                      <span className="text-sm">
                        {chef.location || "Location not specified"}
                      </span>
                    </div>

                    <div className="flex items-center text-gray-600 mb-2">
                      <Clock className="h-4 w-4 mr-1" />
                      <span className="text-sm">
                        {chef.experience_years} years experience
                      </span>
                    </div>

                    <div className="flex items-center text-gray-600 mb-4">
                      <Users className="h-4 w-4 mr-1" />
                      <span className="text-sm">
                        {chef.total_reviews} reviews
                      </span>
                    </div>

                    {chef.cuisines && chef.cuisines.length > 0 && (
                      <div className="mb-4">
                        <div className="flex flex-wrap gap-1">
                          {chef.cuisines.slice(0, 3).map((cuisine, index) => (
                            <span
                              key={index}
                              className="px-2 py-1 bg-orange-100 text-orange-800 text-xs rounded-full"
                            >
                              {cuisine}
                            </span>
                          ))}
                          {chef.cuisines.length > 3 && (
                            <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                              +{chef.cuisines.length - 3} more
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-2xl font-bold text-gray-900">
                          ${chef.hourly_rate || "0"}
                        </span>
                        <span className="text-gray-600">/hour</span>
                      </div>
                      <a
                        href={`/chef/${chef.id}`}
                        className="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
                      >
                        Book Now
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {!isLoading && chefs.length === 0 && (
            <div className="text-center py-12">
              <ChefHat className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-900 mb-2">
                No chefs found
              </h3>
              <p className="text-gray-600">
                Try adjusting your search criteria
              </p>
            </div>
          )}
        </div>
      </section>

      {/* How it Works */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              How It Works
            </h3>
            <p className="text-lg text-gray-600">
              Book a chef in three simple steps
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-orange-500" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                1. Search & Browse
              </h4>
              <p className="text-gray-600">
                Find the perfect chef based on cuisine, location, and reviews
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-orange-500" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                2. Book & Schedule
              </h4>
              <p className="text-gray-600">
                Choose your date, time, and party size for the perfect meal
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <ChefHat className="h-8 w-8 text-orange-500" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                3. Enjoy Your Meal
              </h4>
              <p className="text-gray-600">
                Relax while your chef prepares an amazing dining experience
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <ChefHat className="h-8 w-8 text-orange-500" />
                <h3 className="ml-2 text-xl font-bold">ChefBooking</h3>
              </div>
              <p className="text-gray-400">
                Connecting food lovers with talented chefs for unforgettable
                dining experiences.
              </p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">For Customers</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-white">
                    Find Chefs
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    How it Works
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Reviews
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Support
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">For Chefs</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-white">
                    Become a Chef
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Chef Resources
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Earnings
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Chef Support
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-white">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Careers
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Press
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 ChefBooking. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
