'use client';

import useAuth from "@/utils/useAuth";
import { ChefHat } from 'lucide-react';

export default function LogoutPage() {
  const { signOut } = useAuth();
  
  const handleSignOut = async () => {
    await signOut({
      callbackUrl: "/",
      redirect: true,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <ChefHat className="h-12 w-12 text-orange-500" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Sign Out</h1>
          <p className="text-gray-600 mt-2">Are you sure you want to sign out?</p>
        </div>

        {/* Sign Out Form */}
        <div className="bg-white rounded-lg shadow-lg p-8 space-y-6">
          <div className="text-center space-y-4">
            <p className="text-gray-600">
              You'll need to sign in again to access your account and make bookings.
            </p>
            
            <div className="space-y-3">
              <button
                onClick={handleSignOut}
                className="w-full bg-red-500 text-white px-4 py-3 rounded-lg hover:bg-red-600 transition-colors font-medium"
              >
                Yes, Sign Out
              </button>
              
              <a
                href="/"
                className="block w-full bg-gray-100 text-gray-700 px-4 py-3 rounded-lg hover:bg-gray-200 transition-colors font-medium text-center"
              >
                Cancel
              </a>
            </div>
          </div>
        </div>

        {/* Back to Home */}
        <div className="text-center mt-6">
          <a
            href="/"
            className="text-sm text-gray-500 hover:text-gray-700"
          >
            ← Back to ChefBooking
          </a>
        </div>
      </div>
    </div>
  );
}