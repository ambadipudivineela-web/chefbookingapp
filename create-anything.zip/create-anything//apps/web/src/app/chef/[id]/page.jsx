'use client';

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Star, 
  MapPin, 
  Clock, 
  Users, 
  ChefHat, 
  Calendar, 
  DollarSign,
  Phone,
  Mail,
  Award,
  MessageCircle
} from 'lucide-react';

export default function ChefProfilePage({ params }) {
  const { id } = params;
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [partySize, setPartySize] = useState(2);
  const [specialRequests, setSpecialRequests] = useState('');
  const queryClient = useQueryClient();

  // Fetch chef details
  const { data: chef, isLoading: chefLoading } = useQuery({
    queryKey: ['chef', id],
    queryFn: async () => {
      const response = await fetch(`/api/chefs/${id}`);
      if (!response.ok) throw new Error('Failed to fetch chef');
      const data = await response.json();
      return data.chef;
    },
  });

  // Fetch chef reviews
  const { data: reviewsData } = useQuery({
    queryKey: ['chef-reviews', id],
    queryFn: async () => {
      const response = await fetch(`/api/reviews?chefId=${id}&limit=10`);
      if (!response.ok) throw new Error('Failed to fetch reviews');
      return response.json();
    },
  });

  // Fetch chef menus
  const { data: menusData } = useQuery({
    queryKey: ['chef-menus', id],
    queryFn: async () => {
      const response = await fetch(`/api/chef-menus?chefId=${id}`);
      if (!response.ok) throw new Error('Failed to fetch menus');
      return response.json();
    },
  });

  // Fetch chef availability
  const { data: availabilityData } = useQuery({
    queryKey: ['chef-availability', id],
    queryFn: async () => {
      const response = await fetch(`/api/chef-availability?chefId=${id}`);
      if (!response.ok) throw new Error('Failed to fetch availability');
      return response.json();
    },
  });

  // Create booking mutation
  const createBookingMutation = useMutation({
    mutationFn: async (bookingData) => {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bookingData),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to create booking');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chef-availability', id] });
      setShowBookingModal(false);
      alert('Booking request sent successfully!');
    },
    onError: (error) => {
      alert(`Booking failed: ${error.message}`);
    },
  });

  const handleBooking = () => {
    if (!selectedDate || !selectedTime || !partySize) {
      alert('Please fill in all required fields');
      return;
    }

    const totalAmount = (chef?.hourly_rate || 0) * 3; // Assuming 3-hour minimum

    createBookingMutation.mutate({
      userId: 1, // This would come from auth context in a real app
      chefId: parseInt(id),
      bookingDate: selectedDate,
      startTime: selectedTime,
      endTime: `${parseInt(selectedTime.split(':')[0]) + 3}:${selectedTime.split(':')[1]}`, // 3 hours later
      partySize,
      specialRequests,
      totalAmount,
    });
  };

  const reviews = reviewsData?.reviews || [];
  const menus = menusData?.menus || [];
  const availability = availabilityData?.availability || [];

  if (chefLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  if (!chef) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <ChefHat className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Chef not found</h2>
          <p className="text-gray-600">The chef you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <ChefHat className="h-8 w-8 text-orange-500" />
              <h1 className="ml-2 text-2xl font-bold text-gray-900">ChefBooking</h1>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="/" className="text-gray-700 hover:text-orange-500">Home</a>
              <a href="#" className="text-gray-700 hover:text-orange-500">Find Chefs</a>
              <a href="#" className="text-gray-700 hover:text-orange-500">Sign In</a>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Chef Profile Header */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-8">
          <div className="md:flex">
            <div className="md:w-1/3">
              <div className="h-64 md:h-full bg-gradient-to-br from-orange-400 to-red-500 relative">
                {chef.profile_image ? (
                  <img
                    src={chef.profile_image}
                    alt={`${chef.first_name} ${chef.last_name}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <ChefHat className="h-24 w-24 text-white opacity-50" />
                  </div>
                )}
              </div>
            </div>
            
            <div className="md:w-2/3 p-8">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">
                    Chef {chef.first_name} {chef.last_name}
                  </h1>
                  <div className="flex items-center mb-2">
                    <Star className="h-5 w-5 text-yellow-400 fill-current" />
                    <span className="ml-1 text-lg font-medium">{chef.rating || '0.0'}</span>
                    <span className="ml-2 text-gray-600">({chef.total_reviews} reviews)</span>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-3xl font-bold text-gray-900">${chef.hourly_rate}</div>
                  <div className="text-gray-600">per hour</div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="flex items-center text-gray-600">
                  <MapPin className="h-5 w-5 mr-2" />
                  <span>{chef.location || 'Location not specified'}</span>
                </div>
                
                <div className="flex items-center text-gray-600">
                  <Clock className="h-5 w-5 mr-2" />
                  <span>{chef.experience_years} years experience</span>
                </div>
                
                <div className="flex items-center text-gray-600">
                  <Mail className="h-5 w-5 mr-2" />
                  <span>{chef.email}</span>
                </div>
                
                {chef.phone && (
                  <div className="flex items-center text-gray-600">
                    <Phone className="h-5 w-5 mr-2" />
                    <span>{chef.phone}</span>
                  </div>
                )}
              </div>

              {chef.bio && (
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">About</h3>
                  <p className="text-gray-600">{chef.bio}</p>
                </div>
              )}

              <div className="flex space-x-4">
                <button
                  onClick={() => setShowBookingModal(true)}
                  className="flex-1 bg-orange-500 text-white px-6 py-3 rounded-lg hover:bg-orange-600 transition-colors font-medium"
                >
                  Book Now
                </button>
                <button className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                  <MessageCircle className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Specialties */}
            {chef.cuisines && chef.cuisines.length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Specialties</h3>
                <div className="flex flex-wrap gap-2">
                  {chef.cuisines.map((cuisine, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm font-medium"
                    >
                      {cuisine}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Sample Menus */}
            {menus.length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Sample Menus</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {menus.map((menu) => (
                    <div key={menu.id} className="border border-gray-200 rounded-lg p-4">
                      {menu.image_url && (
                        <img
                          src={menu.image_url}
                          alt={menu.name}
                          className="w-full h-32 object-cover rounded-lg mb-3"
                        />
                      )}
                      <h4 className="font-semibold text-gray-900 mb-1">{menu.name}</h4>
                      <p className="text-gray-600 text-sm mb-2">{menu.description}</p>
                      <div className="flex justify-between items-center">
                        <span className="text-lg font-bold text-gray-900">${menu.price}</span>
                        <span className="text-sm text-gray-500">{menu.cuisine_type}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Reviews */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Reviews</h3>
              {reviews.length > 0 ? (
                <div className="space-y-4">
                  {reviews.map((review) => (
                    <div key={review.id} className="border-b border-gray-200 pb-4 last:border-b-0">
                      <div className="flex items-center mb-2">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < review.rating
                                  ? 'text-yellow-400 fill-current'
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="ml-2 text-sm text-gray-600">
                          {new Date(review.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-gray-700">{review.comment}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-600">No reviews yet.</p>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Stats</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Response Rate</span>
                  <span className="font-medium">95%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Response Time</span>
                  <span className="font-medium">Within 1 hour</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Bookings</span>
                  <span className="font-medium">150+</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Repeat Customers</span>
                  <span className="font-medium">85%</span>
                </div>
              </div>
            </div>

            {/* Availability Preview */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Availability</h3>
              {availability.length > 0 ? (
                <div className="space-y-2">
                  {availability.slice(0, 5).map((slot) => (
                    <div key={slot.id} className="flex justify-between text-sm">
                      <span className="text-gray-600">
                        {new Date(slot.date).toLocaleDateString()}
                      </span>
                      <span className="text-gray-900">
                        {slot.start_time} - {slot.end_time}
                      </span>
                    </div>
                  ))}
                  {availability.length > 5 && (
                    <p className="text-sm text-gray-500">+{availability.length - 5} more slots</p>
                  )}
                </div>
              ) : (
                <p className="text-gray-600">No availability shown</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Booking Modal */}
      {showBookingModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Book Chef {chef.first_name}</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Start Time</label>
                <input
                  type="time"
                  value={selectedTime}
                  onChange={(e) => setSelectedTime(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Party Size</label>
                <select
                  value={partySize}
                  onChange={(e) => setPartySize(parseInt(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                >
                  {[...Array(12)].map((_, i) => (
                    <option key={i + 1} value={i + 1}>
                      {i + 1} {i === 0 ? 'person' : 'people'}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Special Requests</label>
                <textarea
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  rows={3}
                  placeholder="Any dietary restrictions, preferences, or special requests..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Estimated Total (3 hours)</span>
                  <span className="text-xl font-bold text-gray-900">
                    ${(chef.hourly_rate || 0) * 3}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-3 mt-6">
              <button
                onClick={() => setShowBookingModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleBooking}
                disabled={createBookingMutation.isLoading}
                className="flex-1 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors disabled:opacity-50"
              >
                {createBookingMutation.isLoading ? 'Booking...' : 'Book Now'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}