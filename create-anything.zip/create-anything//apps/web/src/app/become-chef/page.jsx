'use client';

import React, { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { ChefHat, MapPin, Clock, DollarSign, Upload, Plus, X } from 'lucide-react';

export default function BecomeChefPage() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: '',
    bio: '',
    experienceYears: '',
    location: '',
    hourlyRate: '',
    selectedCuisines: []
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  // Fetch cuisines for selection
  const { data: cuisines = [] } = useQuery({
    queryKey: ['cuisines'],
    queryFn: async () => {
      const response = await fetch('/api/cuisines');
      if (!response.ok) throw new Error('Failed to fetch cuisines');
      return response.json();
    },
  });

  // Create chef mutation
  const createChefMutation = useMutation({
    mutationFn: async (chefData) => {
      const response = await fetch('/api/chefs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(chefData),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to register as chef');
      }
      return response.json();
    },
    onSuccess: () => {
      setSuccess('Application submitted successfully! You will be notified once approved.');
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        password: '',
        bio: '',
        experienceYears: '',
        location: '',
        hourlyRate: '',
        selectedCuisines: []
      });
    },
    onError: (error) => {
      setError(error.message);
    },
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleCuisineToggle = (cuisineId) => {
    setFormData(prev => ({
      ...prev,
      selectedCuisines: prev.selectedCuisines.includes(cuisineId)
        ? prev.selectedCuisines.filter(id => id !== cuisineId)
        : [...prev.selectedCuisines, cuisineId]
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Validation
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.password) {
      setError('Please fill in all required fields');
      setLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters long');
      setLoading(false);
      return;
    }

    if (formData.selectedCuisines.length === 0) {
      setError('Please select at least one cuisine specialty');
      setLoading(false);
      return;
    }

    try {
      await createChefMutation.mutateAsync({
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        password: formData.password,
        bio: formData.bio,
        experienceYears: parseInt(formData.experienceYears) || 0,
        location: formData.location,
        hourlyRate: parseFloat(formData.hourlyRate) || null,
        cuisines: formData.selectedCuisines
      });
    } catch (err) {
      // Error handled in mutation
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <ChefHat className="h-8 w-8 text-orange-500" />
              <h1 className="ml-2 text-2xl font-bold text-gray-900">ChefBooking</h1>
            </div>
            <nav className="flex space-x-8">
              <a href="/" className="text-gray-700 hover:text-orange-500">Home</a>
              <a href="/account/signin" className="text-gray-700 hover:text-orange-500">Sign In</a>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <ChefHat className="h-16 w-16 text-orange-500" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Become a Chef Partner</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Join our network of professional chefs and bring restaurant-quality dining experiences directly to customers' homes
          </p>
        </div>

        {/* Benefits */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="text-center p-6 bg-white rounded-lg shadow-md">
            <DollarSign className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Flexible Earnings</h3>
            <p className="text-gray-600">Set your own rates and work on your schedule. Earn $50-150+ per hour.</p>
          </div>
          
          <div className="text-center p-6 bg-white rounded-lg shadow-md">
            <Clock className="h-12 w-12 text-blue-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Choose Your Hours</h3>
            <p className="text-gray-600">Work when you want. Full-time, part-time, or just weekends - it's up to you.</p>
          </div>
          
          <div className="text-center p-6 bg-white rounded-lg shadow-md">
            <MapPin className="h-12 w-12 text-purple-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Local Opportunities</h3>
            <p className="text-gray-600">Cook for families and events in your area. Build lasting relationships with clients.</p>
          </div>
        </div>

        {/* Application Form */}
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Chef Application</h2>
          
          {success && (
            <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg text-green-700">
              {success}
            </div>
          )}

          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Personal Information */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Personal Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    First Name *
                  </label>
                  <input
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Last Name *
                  </label>
                  <input
                    type="text"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Password *
                  </label>
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="Create a secure password (min. 6 characters)"
                  />
                </div>
              </div>
            </div>

            {/* Professional Information */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Professional Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Years of Experience
                  </label>
                  <input
                    type="number"
                    name="experienceYears"
                    value={formData.experienceYears}
                    onChange={handleInputChange}
                    min="0"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Hourly Rate ($)
                  </label>
                  <input
                    type="number"
                    name="hourlyRate"
                    value={formData.hourlyRate}
                    onChange={handleInputChange}
                    min="0"
                    step="0.01"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="Your desired hourly rate"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Location
                  </label>
                  <input
                    type="text"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="City, State"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Professional Bio
                  </label>
                  <textarea
                    name="bio"
                    value={formData.bio}
                    onChange={handleInputChange}
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="Tell us about your culinary background, specialties, and what makes you unique..."
                  />
                </div>
              </div>
            </div>

            {/* Cuisine Specialties */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Cuisine Specialties *</h3>
              <p className="text-sm text-gray-600 mb-4">Select all cuisines you specialize in:</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {cuisines.map((cuisine) => (
                  <button
                    key={cuisine.id}
                    type="button"
                    onClick={() => handleCuisineToggle(cuisine.id)}
                    className={`px-4 py-2 rounded-lg border text-sm font-medium transition-colors ${
                      formData.selectedCuisines.includes(cuisine.id)
                        ? 'bg-orange-500 text-white border-orange-500'
                        : 'bg-white text-gray-700 border-gray-300 hover:border-orange-500'
                    }`}
                  >
                    {cuisine.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Submit */}
            <div className="pt-6 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600">
                  * Required fields. Your application will be reviewed within 2-3 business days.
                </p>
                <button
                  type="submit"
                  disabled={loading || createChefMutation.isLoading}
                  className="px-8 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading || createChefMutation.isLoading ? 'Submitting...' : 'Submit Application'}
                </button>
              </div>
            </div>
          </form>
        </div>

        {/* Process */}
        <div className="mt-12 bg-white rounded-lg shadow-md p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-orange-500">1</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Apply</h3>
              <p className="text-sm text-gray-600">Submit your application with your culinary background and specialties</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-orange-500">2</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Review</h3>
              <p className="text-sm text-gray-600">Our team reviews your application and conducts a brief interview</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-orange-500">3</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Approve</h3>
              <p className="text-sm text-gray-600">Get approved and set up your chef profile with photos and menus</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-orange-500">4</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Cook</h3>
              <p className="text-sm text-gray-600">Start receiving bookings and cooking amazing meals for customers</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}